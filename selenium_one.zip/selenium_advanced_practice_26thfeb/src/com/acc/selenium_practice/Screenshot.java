package com.acc.selenium_practice;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Screenshot {
	static WebDriver driver;
	public static void main(String args[]) throws InterruptedException
	
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //used for synchronization
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		Thread.sleep(2000);
		Screenshot.screenshot1(driver);
		
	}
	
	 public static void screenshot1(WebDriver driver)//static method coz calling this method directly in other class or without object
	 {
		 File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);// code to take screen shot
		 try
		 {
			// FileUtils.copyFile(src, new File("C:\\screenshots\\"+timestamp()));// screen shot in defined timestamp
			 FileUtils.copyFile(src, new File("C:\\screenshots\\"+System.currentTimeMillis()+"screenshot1.jpg"));//screenshot in system time
		 }
		 catch(IOException e)
		 {
			 System.out.println(e.getMessage());
		 }
		 
	 }
	 public static String timestamp()
	 {
		 return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss ").format(new Date());//defined format
	 }

}
