package com.acc.selenium_practice;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Realtime_Testng {
	WebDriver driver;
	
	
	@BeforeTest
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //used for synchronization
		driver.manage().window().maximize();
		driver.get("https://netbanking.hdfcbank.com/netbanking/");
		//driver.get("https://www.seleniumhq.org/download/");
		int total_farme =driver.findElements(By.tagName("frame")).size();//to check how many frames are there in the page and tagname can be iframe also..
		System.out.println(total_farme);
		
		}
	
	@Test
	public void linking() throws InterruptedException
	{
		//driver.findElement(By.xpath("//a[@alt='Javadoc']")).click();
		driver.switchTo().frame("footer");//if page has frames then go to that frame and perform action
		driver.findElement(By.linkText("Privacy Policy")).click();
		driver.switchTo().defaultContent();//to come out from the particular frame
		
		driver.switchTo().frame(0);// switch to first frame
		driver.findElement(By.name("fldLoginUserId")).sendKeys("444378");
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);// switch to first frame

		Set<String> winIDs =driver.getWindowHandles();
		Iterator<String> it = winIDs.iterator();
		System.out.println("Toatal windows = "+ winIDs.size());//to get windows counts
		String mainWindowID = it.next();
		String firstPopup = it.next();
		System.out.println(mainWindowID);
		System.out.println(firstPopup);


		driver.switchTo().window(firstPopup);
		driver.findElement(By.linkText("Personal")).click();
		//driver.switchTo().defaultContent();
		Thread.sleep(2000);

		driver.switchTo().window(mainWindowID);
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td[2]/table/tbody/tr[1]/td[1]/table/tbody/tr[3]/td[2]/table/tbody/tr[6]/td[2]/a/img")).click();


		
	}
	

}
