package com.acc.selenium_practice;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Rediff_alert {
static WebDriver driver;
	public static void main(String[] args) throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.rediff.com/");
	driver.findElement(By.partialLinkText("Sign in")).click();
	Thread.sleep(2000);
	driver.findElement(By.name("proceed")).click();
	
	Alert a1 = driver.switchTo().alert();// to handle pop-up which is not from web page
	Thread.sleep(3000);
	System.out.println(a1.getText());//to print the error message
	Thread.sleep(2000);
	a1.accept();//to accept the alert

	}

}
