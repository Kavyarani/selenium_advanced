package com.acc.selenium_practice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Testng_Demo2 {
	
	WebDriver driver;
	@Test(priority=1, enabled=false)
	public void register() throws InterruptedException
	{
		
		driver.findElement(By.partialLinkText("SignUp")).click();
		driver.findElement(By.id("userName")).sendKeys("kavya");
		driver.findElement(By.name("firstName")).sendKeys("kavya");
		driver.findElement(By.name("lastName")).sendKeys("rani");
		driver.findElement(By.id("password")).sendKeys("kavyarani1234567");
		driver.findElement(By.xpath("//form/fieldset/div/div[6]/div/div/label")).click();
		driver.findElement(By.id("emailAddress")).sendKeys("kngm@twitter.com");
		driver.findElement(By.xpath("//img[@alt='Ch']")).click();
		
		
		Select s1 = new Select(driver.findElement(By.xpath("//select[@data-handler='selectMonth']")));
		s1.selectByVisibleText("Mar");
		Select s2 = new Select(driver.findElement(By.xpath("//select[@data-handler='selectYear']")));
		s2.selectByVisibleText("1994");
		driver.findElement(By.xpath("//a[contains(.,'29')]")).click();
		Thread.sleep(3000);
	}
	
	@Test(priority=1, enabled=true)
	public void login() throws InterruptedException
	{
		driver.findElement(By.partialLinkText("SignIn")).click();
		driver.findElement(By.name("userName")).sendKeys("lalitha");
		driver.findElement(By.name("password")).sendKeys("password123");
		driver.findElement(By.name("Login")).click();
		//driver.findElement(By.partialLinkText("SignOut")).click();
		Thread.sleep(3000);
	/*	driver.findElement(By.linkText("All Categories")).click();
		driver.findElement(By.linkText("Electronics")).click();
		Thread.sleep(2000);*/
		
		WebElement main = driver.findElement(By.xpath("//span[contains(.,'All Categories')]"));
		Actions act = new Actions(driver); //to hover on the webelement
		act.moveToElement(main);//moving the x path to perform action on that
		WebElement sub = driver.findElement(By.xpath("//span[contains(.,'Electronics')]"));
		act.moveToElement(sub);
		act.click().build().perform();//to sync the mouse actions
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[contains(.,'Head Phone')]")).click();
	
	}
	
	
	@BeforeTest
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://10.250.88.214:8083/TestMeApp");
		
		}
	
	@AfterTest
	public void close_browser()
	{
		
	}

}
