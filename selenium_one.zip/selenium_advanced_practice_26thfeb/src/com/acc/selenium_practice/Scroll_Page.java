package com.acc.selenium_practice;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Scroll_Page {
	 WebDriver driver;
	@BeforeTest
	 
	  public void launch_browser() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //used for synchronization
			driver.manage().window().maximize();
			driver.get("https://www.wikipedia.org/");
			Thread.sleep(2000);
			
		}
	 
	 @Test
		public void Scrollpage() throws InterruptedException
		{
			
			WebElement input = driver.findElement(By.id("searchInput"));
			WebElement search = driver.findElement(By.xpath("//*[@id='search-form']/fieldset/button"));
		 
			Actions actions = new Actions(driver);
			actions.moveToElement(input).click().keyDown(input, Keys.SHIFT)//to press the shift key
			.sendKeys(input, "india") // sending the iput field string
			.keyUp(input, Keys.SHIFT) // making the india to uppercase
			.doubleClick(input) // to select the highted text
			.build().perform();//perform action
			//.contextClick() // to right click

			
			JavascriptExecutor js = (JavascriptExecutor) driver; // js executor for scrolling the page and repalcement of sendkeys
			//js.executeScript("arguments[0].value='india';",input );//to send search item
			js.executeScript("arguments[0].style.border='7px dotted blue'", input);//click on the icon
			js.executeScript("arguments[0].click();", search);//to highlight the field
			js.executeScript("window.scrollBy(50,4000)");// to scroll the page
			
			js.executeScript("alert('Welcome to page kavya ');");// to create the pop-up
			Thread.sleep(2000);
			driver.switchTo().alert().accept();// to accept the pop-up
			driver.close();  
		}	
	 
	

}
