package com.acc.selenium_practice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.ui.Select;

public class Hello_selenium {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("hello");
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.newtours.demoaut.com/");
		/*driver.findElement(By.name("q")).sendKeys("today");*/
		driver.findElement(By.linkText("REGISTER")).click();
		driver.findElement(By.name("firstName")).sendKeys("kavya");
		driver.findElement(By.name("lastName")).sendKeys("rani");
		driver.findElement(By.name("phone")).sendKeys("1234567890");
		driver.findElement(By.xpath("//*[@id='userName']")).sendKeys("kngm@twitter.com");
		/*driver.findElement(By.name("country")).sendKeys("India");*/
		WebElement CNT = driver.findElement(By.name("country"));
		Select s1 = new Select(CNT);
		/*s1.selectByVisibleText("INDIA");*/
		//s1.selectByValue("92");
		s1.selectByIndex(107);
		driver.findElement(By.name("register")).click();
		driver.findElement(By.partialLinkText("sign-in")).click();
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		driver.findElement(By.xpath("//form/table/tbody/tr[2]/td[2]/b/font/input[2]")).click();
		WebElement Passenger = driver.findElement(By.name("passCount"));
		Select s2 = new Select (Passenger);
		s2.selectByValue("2");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form/table/tbody/tr[9]/td[2]/font/font/input[1]")).click();
		driver.close();//current tab closing
	//	driver.quit();//to close all the tabs
		
	}

}
