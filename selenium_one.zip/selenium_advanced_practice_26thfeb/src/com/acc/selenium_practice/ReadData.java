package com.acc.selenium_practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ReadData {
	WebDriver driver;
	
	 @Test 
	 public void Readtable() throws InterruptedException{
		/*driver.findElement(By.partialLinkText("SignIn")).click();
		driver.findElement(By.name("userName")).sendKeys("lalitha");
		driver.findElement(By.name("password")).sendKeys("password123");
		driver.findElement(By.name("Login")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='menu3']/li[4]/a/span")).click();*/
		 
		 
		driver.findElement(By.xpath("//*[@id='homewrapper']/div[5]/a[3]/div/u")).click();
		driver.findElement(By.partialLinkText("Gainers / Losers")).click();
		driver.findElement(By.partialLinkText("Group A")).click();
		
		int rowcount = driver.findElements(By.tagName("tr")).size();
		System.out.println("Row cont : "+rowcount);
		int colcount = driver.findElements(By.tagName("td")).size();
		System.out.println("Column count : "+colcount);
		//print table
		
		/*for (WebElement ttable:driver.findElements(By.xpath("//*[@id='leftcontainer']/table")))
		{
			System.out.println(ttable.getText());
		}
		*/
		
		// To print one row
		int rownum = 6;
		for (WebElement trow1:driver.findElements(By.xpath("//div[@id='leftcontainer']//tbody//tr["+rownum+"]")))
		{
			System.out.println(trow1.getText());
		}
		int linkcount = driver.findElements(By.xpath("//form/table/tbody/tr/td[5]/a")).size(); //to count link elements in a table
		System.out.println(linkcount);
	 
	 }
	
	 @BeforeTest
	 
	  public void launch_browser()
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //used for synchronization
			driver.manage().window().maximize();
			//driver.get("http://10.250.88.214:8083/TestMeApp2.2/");
			driver.get("https://www.rediff.com/");
		}
	

}
