package com.acc.selenium_practice;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class NewWebsite {
	WebDriver driver;
  @Test
  public void windowHandle()
  {
	  Set<String> winIDs =driver.getWindowHandles();//two lines are to handle the windows
		Iterator<String> it = winIDs.iterator();
		System.out.println("Toatal windows = "+ winIDs.size());//to get windows counts
		String mainWindowID = it.next();
		
		for(int i=1; i<winIDs.size(); i++)
		{
			driver.switchTo().window(it.next());
			driver.close();
		}
		driver.switchTo().window(mainWindowID);
		

  }
  @BeforeTest
  public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //used for synchronization
		driver.manage().window().maximize();
		driver.get("https://www.naukri.com/");
		
	}

  @AfterTest
  public void afterMethod() {
  }

}
